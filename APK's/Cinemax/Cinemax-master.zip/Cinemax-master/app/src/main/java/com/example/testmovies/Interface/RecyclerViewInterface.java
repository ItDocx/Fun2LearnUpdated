package com.example.testmovies.Interface;

public interface RecyclerViewInterface {

     void OnitemClickedListener(int position);



    }

