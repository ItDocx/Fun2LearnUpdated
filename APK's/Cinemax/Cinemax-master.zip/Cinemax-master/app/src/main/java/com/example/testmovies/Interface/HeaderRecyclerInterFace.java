package com.example.testmovies.Interface;

public interface HeaderRecyclerInterFace {

    void OnHeaderitemClickedListener(int position);

}
